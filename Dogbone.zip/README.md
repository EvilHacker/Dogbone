# Dogbone
A Fusion360 addin that creates dogbone joints for wood joinery.

## Usage:
First see [How to install sample Add-Ins and Scripts](https://rawgit.com/AutodeskFusion360/AutodeskFusion360.github.io/master/Installation.html)

See a youtube video of using this app here:
http://youtu.be/EM13Dz4Mqnc

## License
Samples are licensed under the terms of the [MIT License](http://opensource.org/licenses/MIT). Please see the [LICENSE](LICENSE) file for full details.

## Written by

Modified by Patrick Rainsberry <br /> (Autodesk Fusion 360 Business Development)
Forked from: http://github.com/caseycrogers/Dogbone
